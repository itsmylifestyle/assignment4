package data.inter;

import java.sql.Connection;

public interface IDBManager {
    public Connection getConnection();
}
